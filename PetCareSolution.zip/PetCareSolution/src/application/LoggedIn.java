//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
//this class holds the info of the logged in user in order to view it once he is logged in 
package application;

public class LoggedIn {
	public static String loggedIn,loggedName,loggedID,loggedGender;
}
