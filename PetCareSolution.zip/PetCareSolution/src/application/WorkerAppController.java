//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;

import application.Handler;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Callback;

public class WorkerAppController implements WorkerAppControllerInterface{
	@FXML Button connectionManagerButton,refreshButton;
	ServerSocket ss;
	
	ObservableList<ObservableList> data;
    @FXML TableView tableview;
	@FXML Button acceptButton;
	@FXML TextField selectedOID;
	@FXML Label balanceLabel;
	
	

	public void letsConnect(ActionEvent e) throws Exception {		
		Server server = new Server();
		Thread thread = new Thread(server);
		thread.start();
	}
	
	public void acceptButtonPressed(ActionEvent e) throws SQLException {
		String selectedOIDtoDB = selectedOID.getText();
		
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/pet_care_solution","root", "");
		Statement statement = connection.createStatement();
		statement.executeUpdate("UPDATE orders SET Handled = 1 WHERE OID = "+selectedOIDtoDB);
		
		int creditLocal = Integer.parseInt(Worker.credit);
		creditLocal+=50;
		Worker.credit = Integer.toString(creditLocal);
		
		Statement statement2 = connection.createStatement();
		statement2.executeUpdate("UPDATE handlers SET credit = "+Worker.credit+" WHERE Name = '"+Worker.workerName+"'");
		
		Statement statement3 = connection.createStatement();

		ResultSet resultSet2 = statement3.executeQuery("SELECT * FROM `handlers` WHERE Name='"+Worker.workerName+"'");
		resultSet2.next();
		balanceLabel.setText(resultSet2.getString(5));
	}
	
	public void prepareTableView() {
		balanceLabel.setText(Worker.credit);
		Connection c;
        data = FXCollections.observableArrayList();
        try {
            c = DBConnect.connect();
            //SQL FOR SELECTING ALL OF CUSTOMER
            String SQL = "SELECT * from orders";
            //ResultSet
            ResultSet rs = c.createStatement().executeQuery(SQL);
 
            /**
             * ********************************
             * TABLE COLUMN ADDED DYNAMICALLY *
             *********************************
             */
            for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                //We are using non property style for making dynamic table
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1));
                col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });
 
                tableview.getColumns().addAll(col);
                System.out.println("Column [" + i + "] ");
            }
 
            /**
             * ******************************
             * Data added to ObservableList *
             *******************************
             */
            while (rs.next()) {
                //Iterate Row
                ObservableList<String> row = FXCollections.observableArrayList();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    //Iterate Column
                    row.add(rs.getString(i));
                }
                System.out.println("Row [1] added " + row);
                data.add(row);
 
            }
 
            //FINALLY ADDED TO TableView
            tableview.setItems(data);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error on Building Data");
        }
    }
}