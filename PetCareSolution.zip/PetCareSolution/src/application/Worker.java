//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
package application;

public class Worker {
	public static String credit,workerName;

}
