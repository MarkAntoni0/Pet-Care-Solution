//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
//This class allows the Worker App class to initiate a connection to the DB to grab the data to be 
//inserted into the table view for the worker to pick from

package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {

    private static Connection conn;
    private static String url = "jdbc:mysql://localhost/pet_care_solution";
    private static String user = "root";
    private static String pass = "";

    @SuppressWarnings("deprecation")
	public static Connection connect() throws SQLException{
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        }catch(ClassNotFoundException cnfe){
            System.err.println("Error: "+cnfe.getMessage());
        }catch(InstantiationException ie){
            System.err.println("Error: "+ie.getMessage());
        }catch(IllegalAccessException iae){
            System.err.println("Error: "+iae.getMessage());
        }

        conn = DriverManager.getConnection(url,user,pass);
        return conn;
    }
    
    //this function returns the connection of the DB
    public static Connection getConnection() throws SQLException, ClassNotFoundException{
        if(conn !=null && !conn.isClosed())
            return conn;
        connect();
        return conn;

    }
}