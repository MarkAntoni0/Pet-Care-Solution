//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
package application;

import javafx.event.ActionEvent;

public interface Start2ControllerInterface {
	public void loginButtonPressed(ActionEvent e);	
}
