//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
//this class is the responsible for the notification manager in the system
package application;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread{
	
	public void run(){
		ServerSocket ss;
		try {
			ss = new ServerSocket(3600);
			while(true) {
				Socket socket = ss.accept();
				Handler myHandler = new Handler(socket);
				myHandler.start();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		


	}
}
