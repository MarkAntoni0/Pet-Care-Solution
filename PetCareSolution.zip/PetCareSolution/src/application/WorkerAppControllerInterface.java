//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
package application;

import java.sql.SQLException;

import javafx.event.ActionEvent;

public interface WorkerAppControllerInterface {
	public void letsConnect(ActionEvent e) throws Exception;
	public void prepareTableView();
	public void acceptButtonPressed(ActionEvent e) throws SQLException;
	
}
