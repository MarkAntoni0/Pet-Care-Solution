package application;

public class Equations {
	//this function allows the system to generate random order id for each new order raised
	public int getRandom() {
		int min = 0;
	    int max = 500000;
	    int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);
	    return random_int;
	}
}
