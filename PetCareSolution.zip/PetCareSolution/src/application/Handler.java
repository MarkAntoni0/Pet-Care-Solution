//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
//this is the maulti threading socket handler 
package application;

import java.io.*;
import java.util.*;
import java.net.*;
import javax.swing.*;

public class Handler extends Thread{
	Socket socket;
	DataInputStream dataFromClient;
	DataOutputStream dataToClient;
	
	
	public Handler(Socket socket) throws IOException {
		super();
		this.socket = socket;
	}
	
	public void run() {
		JOptionPane.showMessageDialog(null, "New order is raised");
	}
}
