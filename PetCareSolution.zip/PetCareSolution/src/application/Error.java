//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
//This is the failed login error box based on JavaFX
package application;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class Error {
	public static void displayError() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText("Incorrect Credentials!");
        alert.setContentText("Please try again.");
        alert.show();
    }
}
