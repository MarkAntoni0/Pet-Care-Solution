//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
//this class verifies the user name and password of the worker
package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Start2Controller implements Start2ControllerInterface{
	@FXML Button loginButton;
	@FXML TextField usernameField;
	@FXML PasswordField passwordField;
	
	
	public void loginButtonPressed(ActionEvent e) {
		Connection connection;
		try {
			//connecting to the DB
			connection = DriverManager.getConnection("jdbc:mysql://localhost/pet_care_solution","root", "");
			System.out.println("Database connected");
			//Log in query
			Statement statement = connection.createStatement();

			ResultSet resultSet = statement.executeQuery("SELECT * FROM `handlers` WHERE Name='"+usernameField.getText()+"'");
			resultSet.next();
			
			//getting data out of the result set components
			Worker.workerName = resultSet.getString(2);
			String password = resultSet.getString(4);
			Worker.credit = resultSet.getString(5);
			resultSet.close();
			
			//verifying the password value
			if(passwordField.getText().equals(password)) {
				System.out.println("Successful login");
				
				Stage stage2 = (Stage) loginButton.getScene().getWindow();
				Pane root2;
				try {
					//creating another stage for a successful login
					root2 = (Pane)FXMLLoader.load(getClass().getResource("WorkerApp.fxml"));
					Scene scene = new Scene(root2,750,500);
					scene.getStylesheets().add(getClass().getResource("WorkerApp.css").toExternalForm());
					stage2.setScene(scene);
					stage2.setTitle("Pet Care Solution - Worker App");

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
			}else { 
				//reaching this means that the password didnt match the one in the DB
				Error.displayError();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			//reaching this means that the password didnt match the one in the DB
			Error.displayError();
			
		}
		
	}

}
