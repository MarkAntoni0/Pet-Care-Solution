//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
// this is the credits screen that shows the names of the developers of the application
package application;

public class Credits {
	final String student1 = "Mark Tharwat";
	final String student2 = "Reham Said";
	
	public void viewCredit() {
		System.out.println("This application was developed by "+student1+" and "+student2);
	}
}
