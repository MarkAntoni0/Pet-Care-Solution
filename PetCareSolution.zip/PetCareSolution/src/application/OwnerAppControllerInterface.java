//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
package application;

import java.sql.SQLException;

import javafx.event.ActionEvent;

public interface OwnerAppControllerInterface {
	public void calculateBillPressed(ActionEvent e);
	public void exportReportPressed(ActionEvent e);
	public void refreshButtonPressed(ActionEvent e) throws SQLException;
	public void sendRequestPressed(ActionEvent e) throws SQLException;
}
