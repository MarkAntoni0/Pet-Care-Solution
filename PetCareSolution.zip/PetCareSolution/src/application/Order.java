//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course

package application;

public class Order extends Equations{
	int OID;
	String duration;
	String petName;
	String phoneNumber;
	boolean handled; //this shows whether the order is handled by a worker or not
	
	//this is the constructor for the new order raised
	public Order(String duration, String petName, String phoneNumber, boolean handled) {
		super();
		OID = getRandom();
		OwnerAppController.raisedOID=OID;
		this.duration = duration;
		this.petName = petName;
		this.phoneNumber = phoneNumber;
		this.handled = handled;
	}
	
	
	
	
	
}
