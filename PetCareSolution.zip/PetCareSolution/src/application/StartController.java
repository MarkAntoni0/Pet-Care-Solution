//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course
//this class verifies the user name and password of the owner
package application;

import java.io.IOException;
import java.sql.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class StartController implements startControllerInterface{
	@FXML Button loginButton;
	@FXML TextField usernameField;
	@FXML PasswordField passwordField;
	@FXML Label wrongEntryLabel;

	public void loginButtonPressed(ActionEvent e){
		LoggedIn.loggedIn = usernameField.getText();

		Connection connection;
		try {
			//connecting to the DB
			connection = DriverManager.getConnection("jdbc:mysql://localhost/pet_care_solution","root", "");
			System.out.println("Database connected");

			//Log in query
			Statement statement = connection.createStatement();

			ResultSet resultSet = statement.executeQuery("SELECT Password FROM `owners` WHERE Name='"+usernameField.getText()+"'");
			resultSet.next();
			String password = resultSet.getString(1);
			resultSet.close();

			//in these lines we are comparing the password inserted to the one in the DB
			if(passwordField.getText().equals(password)) {
				System.out.println("Successful login");
				//creating another stage for a successful login
				Stage stage2 = (Stage) loginButton.getScene().getWindow();
				Pane root2;
				try {
					root2 = (Pane)FXMLLoader.load(getClass().getResource("OwnerApp.fxml"));
					Scene scene = new Scene(root2,750,500);
					scene.getStylesheets().add(getClass().getResource("OwnerApp.css").toExternalForm());
					stage2.setScene(scene);
					stage2.setTitle("Pet Care Solution - Owner App");

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				//Update info query
				//these lines allows the user to see the profile info on the screen
				Statement statement2 = connection.createStatement();
				ResultSet resultSet2 = statement2.executeQuery("SELECT * FROM `owners` WHERE Name='"+usernameField.getText()+"'");
				resultSet2.next();
				LoggedIn.loggedID = resultSet2.getString(1);
				LoggedIn.loggedName = resultSet2.getString(2);
				LoggedIn.loggedGender = resultSet2.getString(3);	
			}else {
				//reaching this means that the password didnt match the one in the DB
				wrongEntryLabel.setText("Invalid Credentials, try again!");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			//reaching this means that the password didnt match the one in the DB
			wrongEntryLabel.setText("Invalid Credentials, try again!");
		}
	}
}
