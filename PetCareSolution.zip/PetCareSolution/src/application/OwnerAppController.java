//Mark Tharwat & Reham Said - AAST - CS - Advanced programming application course

package application;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class OwnerAppController implements OwnerAppControllerInterface{
	@FXML TextField duration;
	@FXML TextField petName;
	@FXML Button sendRequestButton;
	@FXML Button calculateBillButton;
	@FXML TextField phoneNumber;
	@FXML Label totalCost;
	@FXML Label dayCost;
	@FXML Button exportBillButton;
	@FXML Label loggedName,loggedID,loggedGender;
	@FXML Button refreshButton;
	@FXML Label statusField;
	
	String totalCostS; //totalCostS is the string representation of the totalCost Int that is being calculated in the app
	
	public static int raisedOID=0; //this is the initial orderID
	
	//this function calculates the bill to the user
	public void calculateBillPressed(ActionEvent e) {

		int totalCostI = Integer.parseInt(dayCost.getText()) * (Integer.parseInt(duration.getText()));
		totalCostS = String.valueOf(totalCostI);
		System.out.println("Total cost is: "+totalCostS);
		
		totalCost.setText(totalCostS);
		loggedName.setText(LoggedIn.loggedName);
		loggedID.setText(LoggedIn.loggedID);
		loggedGender.setText(LoggedIn.loggedGender);
	}
	//this function exports a text file including a receipt like report to be printed
	public void exportReportPressed(ActionEvent e) {
		//this is the export destination
		File exportDestination = new File("C:\\Users\\Me\\Desktop\\Report.txt");
		PrintWriter myWriter;
		try {
			myWriter = new PrintWriter(exportDestination);
			myWriter.write("--PET CARE SOLUTION--\n"+"\n"+"Owner: "+LoggedIn.loggedIn+"\nDuration: "+duration.getText()+"\n"+"Total Cost: "+totalCostS);
			myWriter.flush();
			myWriter.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public void sendRequestPressed(ActionEvent e) throws SQLException {
		Order newOrder = new Order(duration.getText(), petName.getText(), phoneNumber.getText(), false);
		Connection connection;
		connection = DriverManager.getConnection("jdbc:mysql://localhost/pet_care_solution","root", "");
		System.out.println("Database connected");
		
		Statement statement2 = connection.createStatement();
		String query1 = "INSERT INTO `orders` (`OID`, `Duration`, `phone number`, `Handled`) " + "VALUES ('"+newOrder.OID+"', '"+newOrder.duration+"', '"+newOrder.phoneNumber+"', '0')";
		statement2.executeUpdate(query1);
		
		try {
			Socket socket = new Socket("localhost",3600);
			
			DataInputStream dataFromServer = new DataInputStream(socket.getInputStream());
			DataOutputStream dataToServer = new DataOutputStream(socket.getOutputStream());
			
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public void refreshButtonPressed(ActionEvent e) throws SQLException {
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/pet_care_solution","root", "");
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery("SELECT Handled FROM `orders` WHERE OID="+raisedOID);
		resultSet.next();
		String handledStatus = resultSet.getString(1);
		if(handledStatus.equals("1")) {
			statusField.setText("Accepted");
		}
	}
}
